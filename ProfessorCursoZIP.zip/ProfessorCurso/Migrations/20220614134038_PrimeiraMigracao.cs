﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace ProfessorCurso.Migrations
{
    public partial class PrimeiraMigracao : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "TablelaDeCurso",
                columns: table => new
                {
                    IdProfessor = table.Column<Guid>(nullable: false),
                    NomeProfessor = table.Column<string>(nullable: true),
                    IdCurso = table.Column<Guid>(nullable: false),
                    NomeCurso = table.Column<string>(nullable: true),
                    Descricao = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TablelaDeCurso", x => x.IdProfessor);
                });

            migrationBuilder.CreateTable(
                name: "TablelaDeProfessor",
                columns: table => new
                {
                    IdProfessor = table.Column<Guid>(nullable: false),
                    NomeProfessor = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TablelaDeProfessor", x => x.IdProfessor);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "TablelaDeCurso");

            migrationBuilder.DropTable(
                name: "TablelaDeProfessor");
        }
    }
}

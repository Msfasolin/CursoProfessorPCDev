﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace ProfessorCurso.Migrations
{
    public partial class AdicionarProfessor : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "NomeProfessor",
                table: "TablelaDeCurso");

            migrationBuilder.AddColumn<Guid>(
                name: "NomeProfessorIdProfessor",
                table: "TablelaDeCurso",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_TablelaDeCurso_NomeProfessorIdProfessor",
                table: "TablelaDeCurso",
                column: "NomeProfessorIdProfessor");

            migrationBuilder.AddForeignKey(
                name: "FK_TablelaDeCurso_TablelaDeProfessor_NomeProfessorIdProfessor",
                table: "TablelaDeCurso",
                column: "NomeProfessorIdProfessor",
                principalTable: "TablelaDeProfessor",
                principalColumn: "IdProfessor",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_TablelaDeCurso_TablelaDeProfessor_NomeProfessorIdProfessor",
                table: "TablelaDeCurso");

            migrationBuilder.DropIndex(
                name: "IX_TablelaDeCurso_NomeProfessorIdProfessor",
                table: "TablelaDeCurso");

            migrationBuilder.DropColumn(
                name: "NomeProfessorIdProfessor",
                table: "TablelaDeCurso");

            migrationBuilder.AddColumn<string>(
                name: "NomeProfessor",
                table: "TablelaDeCurso",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}

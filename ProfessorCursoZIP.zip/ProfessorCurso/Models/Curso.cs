﻿using ProfessorCurso.ViewModel;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace ProfessorCurso.Models
{
    public class Curso : Item
    {
        public Curso()
        {
        
        }


        public Curso(CursoViewModel cursoRecebido)
        {
            NomeCurso = cursoRecebido.NomeCurso;
            Descricao = cursoRecebido.Descricao;
            IdCurso = Guid.NewGuid();
        }

        public Professor NomeProfessor { get; set; }
        public Guid IdCurso { get; set; }
        public new string NomeCurso { get; set; }
        public new string Descricao { get; set; }



    }
}

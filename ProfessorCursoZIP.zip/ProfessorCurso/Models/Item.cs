﻿using ProfessorCurso.Respository;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace ProfessorCurso.Models
{
    public class Item
    {
        [Key]
        public Guid IdProfessor { get; set; }
        public string NomeCurso { get; set; }

        public string Descricao { get; set; }

        public string NomeProfessor { get; set; }

        public Item()
        {
            IdProfessor = Guid.NewGuid();
        }
    }
}

﻿using ProfessorCurso.ViewModel;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace ProfessorCurso.Models
{
    public class Professor
    {

        public Professor()
            {
            }

        public Professor(ProfessorViewModel professorBase)
        {

            NomeProfessor = professorBase.NomeProfessor;
            IdProfessor = Guid.NewGuid();
        }

        [Key]
        public Guid IdProfessor { get; set; }
        public string NomeProfessor { get; set; }



    }
}

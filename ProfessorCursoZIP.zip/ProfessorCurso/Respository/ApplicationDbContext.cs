﻿using Microsoft.EntityFrameworkCore;
using ProfessorCurso.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace ProfessorCurso.Respository
{
    public class ApplicationDbContext : DbContext
    {
        public DbSet<Professor> TablelaDeProfessor { get; set; }
        public DbSet<Curso> TablelaDeCurso { get;  set;}

        protected override void OnConfiguring(
            DbContextOptionsBuilder construtor)
        {
            string conexao = "Server=localhost\\SQLEXPRESS;" + "Database=ProfessorCurso;Integrated Security=SSPI";
            construtor.UseSqlServer(conexao);
        }
    }
}

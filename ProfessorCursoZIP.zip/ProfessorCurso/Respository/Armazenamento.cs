﻿using ProfessorCurso.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace ProfessorCurso.Respository
{
    public class Armazenamento
    {
        public static List<Professor> Professors =
            new List<Professor>();
        public static List<Curso> Cursos =
            new List<Curso>();

    }
}

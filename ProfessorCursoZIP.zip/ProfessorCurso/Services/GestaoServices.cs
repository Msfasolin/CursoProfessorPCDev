﻿using System;
using System.Collections.Generic;
using System.Text;
using ProfessorCurso.Models;
using ProfessorCurso.ViewModel;
using ProfessorCurso.Respository;

namespace ProfessorCurso.Services
{
    public class GestaoServices
    {
        private ApplicationDbContext _context = new ApplicationDbContext();
        /*private List<Curso> _listaCursos =
            Armazenamento.Cursos;*/

        private List<Professor> _listaProfessors = Armazenamento.Professors;


        public Curso CadastrarCurso(CursoViewModel cursoRecebido)
        {
            Curso curso = new Curso(cursoRecebido);


            curso.NomeCurso = cursoRecebido.NomeCurso;

            curso.Descricao = cursoRecebido.Descricao;

            curso.NomeProfessor = new Professor();
            curso.NomeProfessor.NomeProfessor = cursoRecebido.NomeProfessor;


            //_listaCursos.Add(curso);

            _context.TablelaDeCurso.Add(curso);
            _context.SaveChanges();

            return curso;
        }

        public Professor CadastrarProfessor(ProfessorViewModel professorRecebido)
        {
            Professor professor = new Professor(professorRecebido);


            professor.NomeProfessor = professorRecebido.NomeProfessor;




            //_listaProfessors.Add(professor);
            _context.TablelaDeProfessor.Add(professor);
            _context.SaveChanges();

            return professor;
        }


        public List<object> ListarItens()
        {
            List<object> nomeQualquer =
                new List<object>();

            nomeQualquer.AddRange(_context.TablelaDeCurso);
            nomeQualquer.AddRange(_context.TablelaDeProfessor);

            return nomeQualquer;
        }
    }
}

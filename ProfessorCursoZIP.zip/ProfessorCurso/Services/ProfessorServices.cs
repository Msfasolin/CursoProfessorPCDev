﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Data.SqlClient;
using ProfessorCurso.Models;
using ProfessorCurso.Respository;
using ProfessorCurso.ViewModel;

namespace ProfessorCurso.Services
{
    public class ProfessorServices
    {
        private ApplicationDbContext _context = new ApplicationDbContext();
        public Professor CadastrarProfessor(ProfessorViewModel professorRecebeido)
        {
            Professor professor = new Professor(professorRecebeido);

            try
            {
                _context.TablelaDeProfessor.Add(professor);
            }
            catch
            {
            }

            //Armazenamento.Professors.Add(professor);
            //_context.TablelaDeProfessor.Add(professor);

            return professor;
        }

        public List<Professor> ListarProfessors()
        {



            //return Armazenamento.Professors
            return _context.TablelaDeProfessor
                .OrderBy(professor => professor.NomeProfessor)
                .ToList();
        }  

        public Professor ObterCliente(string idRecebido)
        {
            List<Professor> lista = ListarProfessors();
            if (lista.Any(u => u.IdProfessor.ToString() == idRecebido))
            {
                Professor professor = lista
                   .Where(u => u.IdProfessor.ToString() == idRecebido)
                   .First();
                return professor;
            }

            return null;
        }

        public Professor ObterProfessor(string id)
        {
            throw new NotImplementedException();
        }
    }
}

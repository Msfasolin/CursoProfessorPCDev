﻿using ProfessorCurso.Models;
using System.Collections.Generic;
using System.Linq;

namespace ProfessorCurso.Services
{
    public class ProfessorServicesBase
    {

        public Professor ObterProfessor(string idRecebido)
        {
            List<Professor> lista = ListarProfessors();
            if (lista.Any(u => u.IdProfessor.ToString() == idRecebido))
            {
                Professor professor = lista
                   .Where(u => u.IdProfessor.ToString() == idRecebido)
                   .First();
                return professor;
            }

            return null;
        }
    }
}
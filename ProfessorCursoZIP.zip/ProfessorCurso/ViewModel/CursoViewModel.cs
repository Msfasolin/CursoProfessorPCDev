﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace ProfessorCurso.ViewModel
{
    // É o que o usuário vai mandar pro
    // seu programa
    public class CursoViewModel
    {
        public string NomeCurso { get; set; }
        public string Descricao { get; set; }

        public string NomeProfessor { get; set; }   
    }
}

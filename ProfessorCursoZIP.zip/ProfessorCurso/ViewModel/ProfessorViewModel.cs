﻿namespace ProfessorCurso.ViewModel
{
    public class ProfessorViewModel
    {
        public string NomeProfessor { get; set; }

    }
}
